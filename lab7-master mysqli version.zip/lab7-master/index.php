<!DOCTYPE html>

<html>
	<head>
		<title></title>
	</head>
	
	<body>
		<form name="wishList" method="GET" action="wishlist.php">
			Show wish list of: <input type="text" name="user" value="" />
				<input type="submit" value="Go" />
				
		</form>
	</body>
	
</html>